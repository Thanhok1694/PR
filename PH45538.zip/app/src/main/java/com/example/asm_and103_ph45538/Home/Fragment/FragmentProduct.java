package com.example.asm_and103_ph45538.Home.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import com.example.asm_and103_ph45538.APIService;
import com.example.asm_and103_ph45538.AccountActivity.ActivityAccount;
import com.example.asm_and103_ph45538.Home.Adapter.ProductAdapter;
import com.example.asm_and103_ph45538.Home.Model.ProductModel;
import com.example.asm_and103_ph45538.RetrofitClient;
import com.example.asm_and103_ph45538.databinding.FragmentProductBinding;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentProduct extends Fragment {

    FragmentProductBinding binding;
    List<ProductModel> productList;
    List<ProductModel> fullProductList; // Lưu trữ tất cả sản phẩm
    ProductAdapter productAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentProductBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        productList = new ArrayList<>();
        fullProductList = new ArrayList<>(); // Khởi tạo danh sách đầy đủ
        productAdapter = new ProductAdapter(productList);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 1, GridLayoutManager.HORIZONTAL, false);
        binding.rcProduct.setLayoutManager(gridLayoutManager);
        binding.rcProduct.setAdapter(productAdapter);

        binding.icPerson.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), ActivityAccount.class);
            startActivity(intent);
        });

        binding.txtAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
    loadData();
            }
        });
        binding.txtQua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              filterByCategory("quả");

            }
        });
        binding.txtHat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterByCategory("hạt");
            }
        });

        binding.btnSearch.setOnClickListener(v -> {
            String query = binding.edtSearch.getText().toString().trim();
            if (!query.isEmpty()) {
                searchProducts(query);
            }
        });

        loadData();
    }

    private void loadData() {
        APIService apiService = RetrofitClient.getInstance().create(APIService.class);
        apiService.getProduct().enqueue(new Callback<List<ProductModel>>() {
            @Override
            public void onResponse(Call<List<ProductModel>> call, Response<List<ProductModel>> response) {
                if (response.isSuccessful()) {
                    List<ProductModel> products = response.body();
                    productAdapter = new ProductAdapter(products);
                    binding.rcProduct.setAdapter(productAdapter);
                    Log.d("FragmentProduct", "Number of products received: " + products.size());
                    productList.clear();
                    productList.addAll(products);
                    fullProductList.clear();
                    fullProductList.addAll(products); // Lưu trữ danh sách đầy đủ
                    productAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<List<ProductModel>> call, Throwable t) {
                Log.e("Main", t.getMessage());
            }
        });
    }

    private void searchProducts(String query) {
        List<ProductModel> filteredList = new ArrayList<>();
        for (ProductModel product : fullProductList) {
            if (product.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(product);
            }
        }
        productAdapter = new ProductAdapter(filteredList);
        binding.rcProduct.setAdapter(productAdapter);
        Log.d("FragmentProduct", "Number of products after search: " + filteredList.size());
        productList.clear();
        productList.addAll(filteredList);
        productAdapter.notifyDataSetChanged();
    }
    private void filterByCategory(String category) {
        List<ProductModel> filteredList = new ArrayList<>();
        for (ProductModel product : fullProductList) {
            if (product.getCate().equalsIgnoreCase(category)) {
                filteredList.add(product);
            }
        }
        updateProductList(filteredList);
    }
    private void updateProductList(List<ProductModel> filteredList) {
        productAdapter = new ProductAdapter(filteredList);
        binding.rcProduct.setAdapter(productAdapter);
        Log.d("FragmentProduct", "Number of products after filter: " + filteredList.size());
        productList.clear();
        productList.addAll(filteredList);
        productAdapter.notifyDataSetChanged();
    }
}
