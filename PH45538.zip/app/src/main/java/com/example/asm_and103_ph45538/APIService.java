package com.example.asm_and103_ph45538;

import com.example.asm_and103_ph45538.Cart.Model.BillModel;
import com.example.asm_and103_ph45538.Home.Model.ProductModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface APIService {

    @GET("products")
    Call<List<ProductModel>> getProduct();

    @GET("products/{id}")
    Call<ProductModel> getProductById(@Path("id") String id);

    @POST("products")
    Call<ProductModel> createProduct(@Body ProductModel productModel);

    @GET("products/search")
    Call<List<ProductModel>> searchProducts(@Query("name") String productName);

    @PUT("products/{id}")
    Call<ProductModel> updateProduct(@Path("id") String id, @Body ProductModel productModel);

    @GET("bills")
    Call<List<BillModel>> getBill();

    @DELETE("bills/{id}")
    Call<Void> deleteBill(@Path("id") String id);

    @POST("bills")
    Call<BillModel> createBill(@Body BillModel billModel);


}
